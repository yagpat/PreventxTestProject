﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;

namespace PreventxTestProject.Pages
{
    public class RegistrationPage
    {
        public IWebDriver WebDriver { get; }

        public RegistrationPage(IWebDriver webDriver)
        {
            WebDriver = webDriver;
        }

        //UI elements/Page objects

        [FindsBy(How = How.Id, Using = "contentBody_txtFirstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_txtLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpGender")]
        public IWebElement Gender { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpAssignedSex")]
        public IWebElement AssignedSex { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpPartnerSex")]
        public IWebElement PartnerSex { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpDay")]
        public IWebElement AgeDay { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpMonth")]
        public IWebElement AgeMonth { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpYear")]
        public IWebElement AgeYear { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_drpEthnicity")]
        public IWebElement Ethnicity { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_ctlContact_txtAddress1")]
        public IWebElement Address1 { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_ctlContact_txtTownCity")]
        public IWebElement TownCity { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_ctlContact_txtCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_ctlContact_txtCounty")]
        public IWebElement Postcode { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_txtEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_txtMobileNumber")]
        public IWebElement MobileNo { get; set; }

        [FindsBy(How = How.Name, Using = "ctl00$contentBody$radContactPreference")]
        public IList<IWebElement> ContactPreferences { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_txtPassword")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_txtPasswordConfirm")]
        public IWebElement PasswordConfirm { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_chkResearchConsent")]
        public IWebElement ResearchContent { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_chkTerms")]
        public IWebElement Terms { get; set; }

        [FindsBy(How = How.Id, Using = "contentBody_btnRegister")]
        public IWebElement RegisterButton { get; set; }

        public String fieldValidation = null;
     
        //Method to Read data from XML
        public void ReadDataFromXML()
        {
            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml("~\\Data\\AutomationTest.xml");
          
            FirstName.SendKeys(xmlDoc.GetElementsByTagName("FirstName").ToString());
            LastName.SendKeys(xmlDoc.GetElementsByTagName("LastName").ToString());

            var genderElement = new SelectElement(Gender);
            genderElement.SelectByIndex(Convert.ToInt32(xmlDoc.GetElementsByTagName("Gender")));

            var assignedSexElement = new SelectElement(AssignedSex);
            assignedSexElement.SelectByIndex(Convert.ToInt32(xmlDoc.GetElementsByTagName("AssignedSex")));

            var partnerSexElement = new SelectElement(PartnerSex);
            partnerSexElement.SelectByIndex(Convert.ToInt32(xmlDoc.GetElementsByTagName("PartnerSex")));

            //Select DOB from Age
            int ageCount = Convert.ToInt32(xmlDoc.GetElementsByTagName("Age"));
            DateTime selectDOB = DateTime.Now.AddYears(-ageCount);
            string day = selectDOB.Day.ToString();
            string month = selectDOB.Month.ToString();
            string year = selectDOB.Year.ToString();

            var ageDayElement = new SelectElement(AgeDay);
            ageDayElement.SelectByValue(day);

            var ageMonthElement = new SelectElement(AgeMonth);
            ageMonthElement.SelectByValue(month);

            var ageYearElement = new SelectElement(AgeYear);
            ageYearElement.SelectByValue(year);

            var EthnicityElement = new SelectElement(Ethnicity);
            EthnicityElement.SelectByText(xmlDoc.GetElementsByTagName("Ethnicity").ToString());

            Address1.SendKeys(xmlDoc.GetElementsByTagName("Address1").ToString());

            TownCity.SendKeys(xmlDoc.GetElementsByTagName("TownCity").ToString());

            var CountyElement = new SelectElement(County);
            CountyElement.SelectByText(xmlDoc.GetElementsByTagName("County").ToString());

            Postcode.SendKeys(xmlDoc.GetElementsByTagName("PostCode").ToString());

            EmailAddress.SendKeys(xmlDoc.GetElementsByTagName("EmailAddress").ToString());

            MobileNo.SendKeys(xmlDoc.GetElementsByTagName("MobileNumber").ToString());

            for (int i = 1; i <= ContactPreferences.Count; i++)
            {
                String Value = ContactPreferences.ElementAt(i).GetAttribute("value");
                if (Value.Equals(xmlDoc.GetElementsByTagName("ContactPreference")))
                {
                    ContactPreferences.ElementAt(i).Click();
                    break;
                }
            }

            Password.SendKeys(xmlDoc.GetElementsByTagName("Password").ToString());

            PasswordConfirm.SendKeys(xmlDoc.GetElementsByTagName("PasswordConfirm").ToString());

            String valueResearchContent = xmlDoc.GetElementsByTagName("ResearchConsent").ToString();
            if(valueResearchContent.Equals("Yes"))  ResearchContent.Click();

            String valueTerms = xmlDoc.GetElementsByTagName("Terms").ToString();
            if (valueTerms.Equals("Yes")) Terms.Click();
         
            //Pass validation node
            fieldValidation = xmlDoc.GetElementsByTagName("Expected_Results_Valication").ToString();
        }

        public void CheckFieldValidationName(string FieldValidation)
        {
            switch (FieldValidation)
            {
                case "EmailAddress":
                    CheckEmailValidation("InputEmail");
                    break;
                case "PostCode":
                    //some code here       
                default:
                    //some code here 
                    break;
            }
        }

        public void CheckEmailValidation(String inputEmail)
        {
            //Using condition
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                              @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                               @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex regex = new Regex(strRegex);
            if (regex.IsMatch(inputEmail))
                Assert.That(true, "Valid email address entered!");
            else
                Assert.That(false, "Invalid email address entered!");

        }
    }
}
