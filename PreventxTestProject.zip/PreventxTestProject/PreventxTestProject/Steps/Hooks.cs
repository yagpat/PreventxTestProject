﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;

namespace PreventxTestProject.Steps
{
    [Binding]
    public sealed class Hooks
    {
        private IWebDriver Driver { get; }
        [BeforeTestRun]
        public void BeforeTestRun()
        {
            Console.WriteLine("** [BeforeTestRun]");
        }

        [AfterTestRun]
        public void AfterTestRun()
        {
            Console.WriteLine("** [AfterTestRun]");
            Driver.Quit();
            Driver.Dispose();
        }
    }
}
