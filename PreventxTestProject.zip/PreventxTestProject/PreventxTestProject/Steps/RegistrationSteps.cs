﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using PreventxTestProject.Pages;
using SeleniumExtras.PageObjects;
using System;
using TechTalk.SpecFlow;

namespace PreventxTestProject.Steps
{
    [Binding]
    public sealed class RegistrationSteps
    {
        RegistrationPage registrationPage = null;
 
        [Given(@"The user sees registration form")]
        public void GivenTheUserSeesRegistrationForm()
        {
            //Add into a separate class
            IWebDriver webDriver = new ChromeDriver();
            webDriver.Navigate().GoToUrl("https://www.sh.uk/register");
            Assert.AreEqual("Register — SH.UK", webDriver.Title);
            registrationPage = new RegistrationPage(webDriver);
            PageFactory.InitElements(webDriver, registrationPage);
        }

        [Given(@"The user fills details required")]

        public void GivenTheUserFillsDetailsRequired()
        {
            //Fill user details from xml
            registrationPage.ReadDataFromXML();
        }

        [When(@"The user submits the form")]
        public void WhenTheUserSubmitsTheForm()
        {
            //registrationPage.RegisterButton.Click();
            registrationPage.CheckFieldValidationName(registrationPage.fieldValidation);
        }

        [Then(@"The user sees dashboard page")]
        public void ThenTheUserSeesDashboardPage()
        {
            Console.WriteLine("Registration completed...");
        }

    }
}
